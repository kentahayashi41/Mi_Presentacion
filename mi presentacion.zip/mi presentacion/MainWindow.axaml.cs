
using Avalonia.Controls;
using Avalonia.Interactivity;

namespace MiPresentacion;

public partial class MainWindow : Window
{
    private bool saludoAlternativo = false;

    private const string MensajeInicial =
        "¡Bienvenido! Completa el formulario para presentarte.";

    public MainWindow()
    {
        InitializeComponent();
    }

    // Evento del botón Presentarme
    private void BtnPresentarme_Click(
        object? sender,
        RoutedEventArgs e)
    {
        string nombre = txtNombre.Text?.Trim() ?? "";
        string apellido = txtApellido.Text?.Trim() ?? "";
        string edadTexto = txtEdad.Text?.Trim() ?? "";

        // Validar nombre
        if (string.IsNullOrWhiteSpace(nombre))
        {
            txtResultado.Text =
                "Advertencia: Debes ingresar tu nombre.";

            txtNombre.Focus();
            return;
        }

        // Validar apellido
        if (string.IsNullOrWhiteSpace(apellido))
        {
            txtResultado.Text =
                "Advertencia: Debes ingresar tu apellido.";

            txtApellido.Focus();
            return;
        }

        // Validar edad numérica
        if (!int.TryParse(edadTexto, out int edad))
        {
            txtResultado.Text =
                "Advertencia: La edad debe ser un número entero.";

            txtEdad.Focus();
            return;
        }

        // Validar edad positiva
        if (edad <= 0)
        {
            txtResultado.Text =
                "Advertencia: La edad debe ser mayor que cero.";

            txtEdad.Focus();
            return;
        }

        // Mostrar presentación
        if (!saludoAlternativo)
        {
            txtResultado.Text =
                $"¡Hola! Mi nombre es {nombre} {apellido}, " +
                $"tengo {edad} años y estoy aprendiendo " +
                "a desarrollar interfaces gráficas con C#.";
        }
        else
        {
            txtResultado.Text =
                $"¡Mucho gusto! Soy {nombre} {apellido}, " +
                $"tengo {edad} años y estoy dando mis primeros " +
                "pasos en el mundo de la programación.";
        }
    }

    // Evento del botón Limpiar
    private void BtnLimpiar_Click(
        object? sender,
        RoutedEventArgs e)
    {
        txtNombre.Text = "";
        txtApellido.Text = "";
        txtEdad.Text = "";

        saludoAlternativo = false;

        txtResultado.Text = MensajeInicial;

        txtNombre.Focus();
    }

    // Evento del botón Cambiar saludo
    private void BtnCambiarSaludo_Click(
        object? sender,
        RoutedEventArgs e)
    {
        saludoAlternativo = !saludoAlternativo;

        if (saludoAlternativo)
        {
            txtResultado.Text =
                "¡Hola! Esta es mi presentación alternativa. " +
                "Estoy aprendiendo a programar con Avalonia UI y C#.";
        }
        else
        {
            txtResultado.Text = MensajeInicial;
        }
    }
}
